"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const ethers_1 = require("ethers");
const contract_1 = __importDefault(require("../contract"));
const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    const nft = (_a = event.queryStringParameters) === null || _a === void 0 ? void 0 : _a.nft;
    const id = (_b = event.queryStringParameters) === null || _b === void 0 ? void 0 : _b.id;
    const provider = new ethers_1.ethers.providers.JsonRpcProvider("https://polygon-mumbai.g.alchemy.com/v2/EU6IHhJ9DWNVfHysQNgH1M-2QJUSSg4S");
    const signer = new ethers_1.ethers.Wallet("06388ecb59b781d905ec67b0450120d8487ceb28d1469bfaa675328a8f0f1eac", provider);
    const contract = new ethers_1.ethers.Contract("0x617b964dfcef78195d895963cf386418658345af", contract_1.default, signer);
    console.log(event);
    const chainId = yield provider.getNetwork().then((network) => network.chainId);
    const hash = yield contract.getSignature([nft, id]);
    const signature = yield signer.signMessage(hash);
    const tx = yield contract.storeNFT({ ctr: nft, tokenId: id }, signature);
    return {
        statusCode: 500,
        body: `${tx.hash}`,
    };
});
exports.handler = handler;
//# sourceMappingURL=nft-sig.js.map